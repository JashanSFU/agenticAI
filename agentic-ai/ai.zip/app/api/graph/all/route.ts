import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  return NextResponse.json({
    nodes: db.graphNodes,
    edges: db.graphEdges,
  });
}
